package math.operation;

public class ArithmeticOperations {

	public Integer add(Integer a, Integer b)
	{
		return a+b;
	}
}
