package com.ayantsoft.testcase;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class MainTestSuite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Result r=JUnitCore.runClasses(TestSuit.class);
		
		for(Failure f:r.getFailures()){
			System.out.println(f.toString());
		}
		System.out.println(r.wasSuccessful());
	}

}
