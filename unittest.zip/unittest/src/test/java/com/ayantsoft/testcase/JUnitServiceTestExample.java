package com.ayantsoft.testcase;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;

import com.ayantsoft.logic.TestService;

/**
 * The Class JUnitServiceTestExample.
 */
public class JUnitServiceTestExample {

	/**
	 * Test1.
	 */
	@Test
	public void testSimpleInt() {
		// create mock
		TestService test = Mockito.mock(TestService.class);

		// define return value for method getUniqueId()
		when(test.getUniqueId()).thenReturn(43);

		// use mock in test....
		assertEquals(test.getUniqueId(), 43);//when test with 43 pass the result but otherwise fail
		
	}
}
