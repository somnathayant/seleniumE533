package com.ayantsoft.assignment3.controller;


import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class EmpController {

	
	@RequestMapping("/")  
	public ModelAndView welcome() {  

		ModelAndView mv=new ModelAndView();
		mv.setViewName("automation2");
		return mv;
	}  
	
	@RequestMapping("/automation1")  
	public ModelAndView automation2() {  

		ModelAndView mv=new ModelAndView();
		mv.setViewName("automation1");
		return mv;
	}  
	
}
