package corsRestForAng4;

import org.hibernate.Session;

import com.ayantsoft.Ang4.hibernate.pojo.Address;
import com.ayantsoft.Ang4.hibernate.pojo.Dept;
import com.ayantsoft.Ang4.hibernate.pojo.Emp;
import com.ayantsoft.Ang4.hibernate.util.HbernateUtil;

public class TetEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Session session=null;
		boolean isEmpSaved=false;
		try{
			Emp emp=new Emp();
			Address add=new Address();
			Dept dept=new Dept();
			
			emp.setName("testRest");
			add.setCity("rest");
			dept.setDeptName("rest");
			
			emp.setAddress(add);
			emp.setDept(dept);
			
			session=HbernateUtil.openSession();
			session.beginTransaction();
			
			session.save(emp.getAddress());
			session.save(emp.getDept());
			session.save(emp);
			isEmpSaved=true;
			
		session.getTransaction().commit();
		System.out.println(isEmpSaved);
		}catch(Exception ex){ex.printStackTrace();
		
		session.getTransaction().rollback();
		}finally{
			session.close();
		}
		
	}

}
