package com.ayantsoft.Ang4.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.sql.Blob;

import org.apache.commons.io.IOUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.Ang4.model.EmployeeDto;
import com.ayantsoft.Ang4.response.Response;

import java.util.*;  
import javax.mail.*;  
import javax.mail.internet.*;
import javax.servlet.http.HttpServletResponse;
import javax.activation.*;  


//as the class is annotated using @RestController now all the controller methods can be accessd by ip address
@RestController
public class EmpController{


	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String index(){

		return "Server Running";
	}


	@RequestMapping(value="/saveEmpData",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/getEmpData
	public ResponseEntity<?> saveEmpData(@RequestBody EmployeeDto empDtoObj){//here data received using @requestBody

		
		System.out.println(empDtoObj.getName());

		HttpStatus httpStatus = null;
		Response res=new Response();
		try{
			boolean isSaved=false;
			if(empDtoObj!=null){
			 isSaved=true;
			}else{
			 isSaved=false;
			}

			if(isSaved) {
				httpStatus=HttpStatus.CREATED;
				res.setMsg("Employee created");
			}else {
				res.setMsg("Employee not created ; some problem occured ; please check status code");
			}
			return new ResponseEntity<Response>(res,httpStatus);
		}catch(Exception ex){
			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("Employee not created ; some problem occured ; please check status code");
			return new ResponseEntity<Response>(res,httpStatus);
		}
	}

	@RequestMapping(value="/emps",method=RequestMethod.GET)
	public ResponseEntity<?> emps(){

		HttpStatus httpStatus = null;
		
		List<EmployeeDto>empDtos=new ArrayList<EmployeeDto>();
		
		Response res=new Response();
		try {
			

			
				httpStatus=HttpStatus.OK;
				
					EmployeeDto eDto=new EmployeeDto();
					EmployeeDto eDto1=new EmployeeDto();
					
					eDto.setEmpId(6);
					eDto.setName("Manoj");
					eDto.setSalary(500000);
					
					eDto.setCity("Texas");
					eDto.setPincode(223311);
					eDto.setState("Alabama");
					eDto.setDeptName("Testing");
					empDtos.add(eDto);					
					
					eDto1.setEmpId(8);
					eDto1.setName("somnath");
					eDto1.setSalary(400000);
					
					eDto1.setCity("Alabama");
					eDto1.setPincode(665544);
					eDto1.setState("Alabama");
					eDto1.setDeptName("Development");

					empDtos.add(eDto1);
			
		}catch(Exception ex) {

			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("No Employee list ; some problem occured ; please check status code");
			return new ResponseEntity<Response>(res,httpStatus);

		}
		return new ResponseEntity<List<EmployeeDto>>(empDtos,httpStatus);
	}

	
}
