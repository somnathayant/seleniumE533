package com.ayantsoft.Ang4.config;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.ayantsoft.Ang4" })
public class WebMvcConfigure extends WebMvcConfigurerAdapter {
	private Logger log = Logger.getLogger(WebMvcConfigure.class);

	public WebMvcConfigure() {
		log.info("WebMvcConfigure OBJECT CREATED");
	}

	
	
	@Bean(name="multipartResolver") 
    public CommonsMultipartResolver getResolver() throws IOException{
        CommonsMultipartResolver resolver = new CommonsMultipartResolver();
         
        //Set the maximum allowed size (in bytes) for each individual file.
        resolver.setMaxUploadSizePerFile(5242880);//5MB
         
        //You may also set other available properties.
         
        return resolver;
    }
	
	
	public MappingJackson2HttpMessageConverter jacksonMessageConverter() {
		try {
			Jackson2ObjectMapperBuilder builder=new Jackson2ObjectMapperBuilder();
			builder.indentOutput(true);
			MappingJackson2HttpMessageConverter messageConverter = new MappingJackson2HttpMessageConverter(builder.build());
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.registerModule(new Hibernate4Module());
			messageConverter.setObjectMapper(objectMapper);

			return messageConverter;
		} catch (Exception e) {
			log.error("jacksonMessageConverter ERROR : ", e);
			return null;
		}
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		try {
			converters.add(jacksonMessageConverter());
			super.configureMessageConverters(converters);

		} catch (Exception e) {
			log.error("configureMessageConverters ERROR : ", e);
		}
	}
	
	
	
}