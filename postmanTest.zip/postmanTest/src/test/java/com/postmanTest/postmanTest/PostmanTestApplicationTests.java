package com.postmanTest.postmanTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostmanTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
