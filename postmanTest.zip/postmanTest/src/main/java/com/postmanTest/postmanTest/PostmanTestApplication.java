package com.postmanTest.postmanTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostmanTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostmanTestApplication.class, args);
	}

}
