package com.ayantsoft.Selenium.webpage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;


//This program shows the use of single page with alert box
//right click on this file and select run as either java application or testNG

public class SinglePageAlert {

	public static void main(String[] args) {
		try{
			WebDriver driver = new FirefoxDriver();

			String baseUrl = "http://localhost:8080/seleniumUltimate/";	
			driver.get(baseUrl);

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		/* Find the button which can trigger popup by it's id. */
			By byId = By.id("btnClick");

			WebElement alertBtn = driver.findElement(byId);

			if(alertBtn!=null)
			{
				/* Click the button to trigger a javascript 
				 * which will popup an dialog.*/
				alertBtn.click();
			}

			/* 
			 * You can process javascript alert, confirm and prompt
			 * with this object.
			 * */
			Alert alertObj = driver.switchTo().alert();

			/* Print out the popup text in the console. */
			System.out.println(alertObj.getText());

			/* Sleep 3 seconds to see the popup dialog. */
			Thread.sleep(3000);

			/* Accept this javascript popup and close it. */
			alertObj.accept();

			System.out.println("Click OK button automatically in testAlert In Selenium method.");
			Thread.sleep(2000);

			


		}catch(Exception ex){

		}

		
		
	}

	@Test
	public void fun(){

		try{
			WebDriver driver = new FirefoxDriver();

			String baseUrl = "http://localhost:8080/seleniumUltimate/";	
			driver.get(baseUrl);

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			/* Find the button which can trigger popup by it's id. */
			By byId = By.id("btnClick");

			WebElement alertBtn = driver.findElement(byId);

			if(alertBtn!=null)
			{
				/* Click the button to trigger a javascript 
				 * which will popup an dialog.*/
				alertBtn.click();
			}

			/* 
			 * You can process javascript alert, confirm and prompt
			 * with this object.
			 * */
			Alert alertObj = driver.switchTo().alert();

			/* Print out the popup text in the console. */
			System.out.println(alertObj.getText());

			/* Sleep 3 seconds to see the popup dialog. */
			Thread.sleep(3000);

			/* Accept this javascript popup and close it. */
			alertObj.accept();

			System.out.println("Click OK button automatically in testAlert In Selenium method.");
			Thread.sleep(2000);

			


		}catch(Exception ex){

		}

	}


}
