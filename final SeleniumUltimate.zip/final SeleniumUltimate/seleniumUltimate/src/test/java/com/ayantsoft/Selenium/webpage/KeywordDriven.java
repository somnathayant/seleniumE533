package com.ayantsoft.Selenium.webpage;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class KeywordDriven {
		
	private String userId;
	private String password;
	private String controll;
	private String event;
	private String controllIdentifier;
	
	@BeforeTest
	public void getData(){
		try{
			System.out.println("ok");
			File file=new File("/home/somnath/Desktop/Data.xlsx");//here your xml file path
			
			FileInputStream finput = new FileInputStream(file);
			XSSFWorkbook    workbook = new XSSFWorkbook(finput);
			XSSFCell  cell=null;
			// Load the sheet in which data is stored.

			XSSFSheet  sheet= workbook.getSheetAt(0);
			
			for(int i=1; i<=sheet.getLastRowNum(); i++)
			{
				System.out.println(i);
				// Import data for userId.
				
				cell = sheet.getRow(i).getCell(0);
				//System.out.println(cell.getStringCellValue());
				// Import data for password.
				cell = sheet.getRow(i).getCell(1);
				//System.out.println(cell.getStringCellValue());
				
				userId=sheet.getRow(i).getCell(0).toString();
				password=sheet.getRow(i).getCell(1).toString();
				controll=sheet.getRow(i).getCell(2).toString();
				event=sheet.getRow(i).getCell(3).toString();
				controllIdentifier=sheet.getRow(i).getCell(4).toString();
				
			}
			workbook.close();
		}catch(Exception ex){

		}
	}
	
	public Integer getFirst(){
		
		return 23;
		
	}
	
	public Integer getSecond(){
		
		return 4;
	}

	@Test
	public void login(){

		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://localhost:8080/seleniumUltimate/";	//here your page url
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebElement userId = driver.findElement(By.id("userid"));					 
		WebElement userPass = driver.findElement(By.id("password"));					 

		userId.sendKeys(this.userId);
		userPass.sendKeys(this.password);
		
		if(this.controll.equalsIgnoreCase("button")){
			WebElement btnButton = driver.findElement(By.id(this.controllIdentifier));
			if(this.event.equalsIgnoreCase("click")){
				btnButton.click();
			}
			
		}
		
	}

	
}
