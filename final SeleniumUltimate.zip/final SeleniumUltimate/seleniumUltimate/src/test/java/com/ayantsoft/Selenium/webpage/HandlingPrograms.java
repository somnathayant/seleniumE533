package com.ayantsoft.Selenium.webpage;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.testng.annotations.Test;

public class HandlingPrograms {

	//if we run this program by run as java appplication it will be without testNG  
	public static void main(String args[]){
		
		try{
			WebDriver driver = new FirefoxDriver();
			String baseUrl = "http://localhost:8080/seleniumUltimate/";	
			driver.get(baseUrl);

			/* Maximize the Firefox browser window. */
			driver.manage().window().maximize();

			
			/* Sleep 2 seconds to wait the page load. */
			Thread.sleep(2000);
			
			WebElement secondPage = driver.findElement(By.id("popUpPage"));					 
			secondPage.click();
			
			//showing  the popUp window
			WebElement showPopUp = driver.findElement(By.id("popUp"));					 
			showPopUp.click();
			
			Thread.sleep(2000);
			
			//closing the popUp window
			WebElement closePopUp = driver.findElement(By.id("popUpClosed"));					 
			closePopUp.click();
			
			
			
			}catch(Exception ex){
				
			}

		
		
	}
	
	
	
	@Test
	public static void popUpTest() {
		// TODO Auto-generated method stub

		//handling alert boxes

		try{
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://localhost:8080/seleniumUltimate/";	
		driver.get(baseUrl);

		/* Maximize the Firefox browser window. */
		driver.manage().window().maximize();

		
		/* Sleep 2 seconds to wait the page load. */
		Thread.sleep(2000);
		
		WebElement secondPage = driver.findElement(By.id("popUpPage"));					 
		secondPage.click();
		
		//showing  the popUp window
		WebElement showPopUp = driver.findElement(By.id("popUp"));					 
		showPopUp.click();
		
		Thread.sleep(2000);
		
		//closing the popUp window
		WebElement closePopUp = driver.findElement(By.id("popUpClosed"));					 
		closePopUp.click();
		
		
		
		}catch(Exception ex){
			
		}
	}

}
