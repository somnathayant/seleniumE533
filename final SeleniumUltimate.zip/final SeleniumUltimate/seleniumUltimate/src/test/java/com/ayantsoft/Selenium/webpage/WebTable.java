package com.ayantsoft.Selenium.webpage;

import java.text.NumberFormat;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;


public class WebTable {


	@Test
	public void fun(){

		try{
			WebDriver driver = new FirefoxDriver();

			String baseUrl = "http://localhost:8080/seleniumUltimate/";	
			driver.get(baseUrl);

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			WebElement secondPage = driver.findElement(By.id("secondPage"));					 

			secondPage.click();
			
			
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			String innerText = driver.findElement(
				By.xpath("//table/tbody/tr[2]/td[2]")).getText(); 	
		       
			System.out.println(innerText); 
		        
		        
		        List  col = driver.findElements(By.xpath("//table/thead/tr/th"));
		        System.out.println("No of cols are : " +col.size()); 
		       
		        //No.of rows 
		        List  rows = driver.findElements(By.xpath("//table/tbody/tr/td")); 
		        System.out.println("No of rows are : " + rows.size());
		        
		        String mValue,max;
		       Double sum=0.0;
		        for (int i =1;i<rows.size();i++)
		        {    
		        	mValue= driver.findElement(By.xpath("//table/tbody/tr[" + (i+1)+ "]/td[2]")).getText();
		        	
		        	
		        	NumberFormat value =NumberFormat.getNumberInstance(); 
		            Number num = value.parse(mValue);
		            max = num.toString();
		            sum = sum+Double.parseDouble(max);
		            System.out.println(sum);
		              }
		        System.out.println(sum);
			       
		        
		        
		        
		        
			driver.quit();

		}catch(Exception ex){

		}
	}
}



