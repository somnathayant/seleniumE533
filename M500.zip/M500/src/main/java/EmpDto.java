

import java.io.Serializable;

public class EmpDto implements Serializable{

	
	/**
	 * serialVersionUID
	 * 
	 */
	private static final long serialVersionUID = -8490773896490535670L;
	
	private Integer id;
	private String name;
	private String password;
	private String email;
	
	private Integer pin;
	private String state;
	private String city;
	
	
	//setter and getter
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getPin() {
		return pin;
	}
	public void setPin(Integer pin) {
		this.pin = pin;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	@Override
	public String toString(){
		return this.city + " " + this.name + " " + this.email ;
	}
	
	
	

}
