import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.Transformers;


import com.ayantsoft.hibernate.pojo.Address;
import com.ayantsoft.hibernate.pojo.Dept;
import com.ayantsoft.hibernate.pojo.Emp;
import com.ayantsoft.hibernate.util.HbernateUtil;



public class ExampleHibernate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hibernate is running");
		Session session=null;
		try{
		 session=HbernateUtil.openSession();
			
		session.beginTransaction();
		
		Emp e=new Emp();
		Address add=new Address();
		Dept d=new Dept();
		
		e.setName("Somnath Biswas");
		e.setEmail("som@gmail.com");
		add.setCity("Alabama");
		add.setPin(221133);
		add.setState("Alabama");
		d.setName("comp.Sc");
		
		e.setAddress(add);
		e.setDept(d);
		
		session.save(add);
		session.save(d);
		session.save(e);
		
		
		session.getTransaction().commit();
		
		
		 session.beginTransaction();
		 Criteria criteria = session.createCriteria(Emp.class,"EMP");
	        criteria.createAlias("EMP.address", "ADDRESS");
	        criteria.setProjection(Projections.projectionList()
	                    .add(Projections.property("id").as( "id"))
	                    .add(Projections.property("name").as("name"))
	                    .add(Projections.property("password").as("password"))
	                    .add(Projections.property("email").as("email"))
	                    .add(Projections.property("ADDRESS.city").as("city"))
	        );
	        criteria.setResultTransformer(Transformers.aliasToBean(EmpDto.class));
		List<EmpDto>eList=criteria.list();
		System.out.println(eList.size());
		
		Iterator <EmpDto>it= eList.iterator();
		while(it.hasNext()){
			System.out.println(it.next().getCity());
		}
		
		session.getTransaction().commit();
		}
		catch(Exception ex){
			session.getTransaction().rollback();
		}
	
	}
}
