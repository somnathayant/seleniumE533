/**
 * 
 */
/**
 * @author somnath
 *
 */
package com.ayantsoft.hibernate.util;