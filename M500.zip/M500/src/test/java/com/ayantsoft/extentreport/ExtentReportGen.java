package com.ayantsoft.extentreport;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportGen {

	public static void main(String []args) {
		System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		
		WebDriver driver = new FirefoxDriver();
		
		
		 // start reporters
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("D:\\extent.html");
    
        // create ExtentReports and attach reporter(s)
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        // creates a toggle for the given test, adds all log events under it    
        ExtentTest test = extent.createTest("Google Search Entry", "Enter value in Search box ");

		
		
		String baseUrl = "https://google.com";	
		driver.get(baseUrl);
		test.log(Status.PASS,"Google page displayed");
		driver.findElement(By.name("q")).sendKeys("Selenium");
		test.log(Status.PASS,"Selenium word entered");
		
		test.log(Status.INFO,"Driver closed");
		
		extent.flush();
		driver.close();
		
	}
	
	
	
	
}
