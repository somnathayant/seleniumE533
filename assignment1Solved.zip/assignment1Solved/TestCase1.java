package com.ayantsoft.assignment1.testing;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class TestCase1 {

	WebDriver driver = new FirefoxDriver();

	@BeforeClass
	public void initialization() {
		System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		String baseUrl = "http://localhost:8080/assignment1/";	
		driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// now copy the  screenshot to desired location using copyFile //method
			FileUtils.copyFile(src, new File("E:/assignment1/TestCase_general_first_pic.png"));//path of image
		}
		catch(Exception ex) {}

	}

	@Test
	public void testCase1() {

		try {
			// start reporters
			ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("E:/assignment1/testcase1/TestCase 1.html");
			// create ExtentReports and attach reporter(s)
			ExtentReports extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			// creates a toggle for the given test, adds all log events under it    
			ExtentTest test = extent.createTest("This test for assignment1 has been started");

			test.log(Status.INFO,"Starting the test case 1");



			WebElement user_name=driver.findElement(By.id("usr-name"));
			WebElement age=driver.findElement(By.id("age"));

			test.log(Status.INFO,"Entered wrong user id and password ---so validation massage should displayed--"+"somnath"+" "+"som@123");

			user_name.sendKeys("som");// wrong value
			age.sendKeys("som@123");//wrong value

			JavascriptExecutor js =(JavascriptExecutor)driver;
			js.executeScript("done();");//here we call testmethod of javascript

			test.log(Status.PASS,"Because of wrong values validation massage is displayed-- So test case1 is done ");

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			File src1= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// now copy the  screenshot to desired location using copyFile //method
			FileUtils.copyFile(src1, new File("E:/assignment1/testcase1/TestCase 1_pic.png"));//path of image
			extent.flush();


		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());

		}
	}
	













}
