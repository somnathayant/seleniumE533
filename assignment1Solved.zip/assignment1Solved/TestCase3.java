package com.ayantsoft.assignment1.testing;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class TestCase3 {

	WebDriver driver = new FirefoxDriver();

	@BeforeClass
	public void initialization() {
		System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		String baseUrl = "http://localhost:8080/assignment1/";	
		driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// now copy the  screenshot to desired location using copyFile //method
			FileUtils.copyFile(src, new File("E:/assignment1/TestCase_general_first_pic.png"));//path of image
		}
		catch(Exception ex) {}

	}
	
	@Test
	public void testCase3() {

		try {
			// start reporters
			ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("E:/assignment1/testcase3/TestCase 3.html");
			// create ExtentReports and attach reporter(s)
			ExtentReports extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			// creates a toggle for the given test, adds all log events under it    
			ExtentTest test = extent.createTest("This test for assignment1 has been started");

			test.log(Status.INFO,"Starting the test case 3");

			WebElement radioBtn=driver.findElement(By.id("employee"));
			WebElement checkBox2=driver.findElement(By.id("chk2"));

			test.log(Status.INFO,"Here we have taken the control over html elements i.e radio button and checkBox 2");

			radioBtn.click();//here we clicked the button
			checkBox2.click();//now we have clicked the checkbox 2 also , So the validation massage should display
			
			test.log(Status.INFO,"Here we have triggred the validation condition Automatadly");

			JavascriptExecutor js =(JavascriptExecutor)driver;
			js.executeScript("done();");//here we call testmethod of javascript

			test.log(Status.PASS,"Because  validation massage is displayed-- So test case3 is done ");

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			File src1= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// now copy the  screenshot to desired location using copyFile //method
			FileUtils.copyFile(src1, new File("E:/assignment1/testcase3/TestCase 3_pic.png"));//path of image
			extent.flush();

		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());

		}

	}

	
}
