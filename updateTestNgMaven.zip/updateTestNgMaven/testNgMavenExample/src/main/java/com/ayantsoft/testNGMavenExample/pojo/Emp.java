package com.ayantsoft.testNGMavenExample.pojo;

public class Emp {
	
	private String name;
	   private int monthlySalary;
	   private int age;
	   
	   // @return the name

	   public String getName() {
	      return name;
	   }
	   
	   // @param name the name to set
	   
	   public void setName(String name) {
	      this.name = name;
	   }
	   
	   // @return the monthlySalary

	   public int getMonthlySalary() {
	      return monthlySalary;
	   }
	   
	   // @param monthlySalary the monthlySalary to set
	   
	   public void setMonthlySalary(int monthlySalary) {
	      this.monthlySalary = monthlySalary;
	   }
	   
	   // @return the age
	 
	   public int getAge() {
	      return age;
	   }
	   
	   // @param age the age to set
	 
	   public void setAge(int age) {
	      this.age = age;
	   }
	}