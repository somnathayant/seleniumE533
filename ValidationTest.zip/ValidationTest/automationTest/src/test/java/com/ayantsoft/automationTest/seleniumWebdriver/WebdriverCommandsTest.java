package com.ayantsoft.automationTest.seleniumWebdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebdriverCommandsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://localhost:8080/automationTest/";	
		driver.get(baseUrl);
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      
	    //By id
	    WebElement user_id=driver.findElement(By.id("usr-id"));
		WebElement passwd=driver.findElement(By.id("password"));
		
		//no such html element as password1
		//WebElement passwd1=driver.findElement(By.id("password1"));
		
		passwd.sendKeys("value added");
	
		//clear() method tested
		passwd.clear();
		if(user_id.isDisplayed()) {
			
		}
		/*if(passwd1.isDisplayed()) {// here as we dont have passwd1 html element so it never worked ,no value in user_id text box
			user_id.sendKeys("value added");
		}*/
		
		
		
	}

}
