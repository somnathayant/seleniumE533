package com.ayantsoft.automationTest.seleniumWebdriver;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

public class JavascriptTest {

	
	@Test
	public void testNameAndPassword1(){
		
		/*System.setProperty("webdriver.chrome.driver", "C:\\Users\\User\\Desktop\\Mariyam\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		*/
		
		/*System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
	*/
		
		
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://localhost:8080/automationTest/";	
		driver.get(baseUrl);
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
	  
	    
	    
	    
	    
		}

	@Test
	public void testNameAndPassword2(){
		
		/*System.setProperty("webdriver.chrome.driver", "C:\\Users\\User\\Desktop\\Mariyam\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		*/
		
		/*System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
	*/
		
		
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://localhost:8080/automationTest/";	
		driver.get(baseUrl);
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}

}
