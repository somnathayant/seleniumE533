package com.ayantsoft.automationTest.seleniumWebdriver;


import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class JavascriptTest {

	
	@Test
	public void testNameAndPassword1(){
		
		/*System.setProperty("webdriver.chrome.driver", "C:\\Users\\User\\Desktop\\Mariyam\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		*/
		
		/*System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
	*/
		
		
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://localhost:8080/automationTest/";	
		driver.get(baseUrl);
		driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      
	    
	   //from here we are generating reports
		
		
		 // start reporters
       ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("D:/javascriptTest.html");
   
       // create ExtentReports and attach reporter(s)
       ExtentReports extent = new ExtentReports();
       extent.attachReporter(htmlReporter);

       
       
       // creates a toggle for the given test, adds all log events under it    
       ExtentTest test = extent.createTest("This test is on various javascript releated ops");
		
		test.log(Status.PASS,"Page for operation is displayed");
		
		WebElement user_id=driver.findElement(By.id("usr-id"));
		WebElement passwd=driver.findElement(By.id("password"));
		
		user_id.sendKeys("");
		passwd.sendKeys("");
		
		test.log(Status.INFO,"Here Test Automation condition is prepared");
		
		JavascriptExecutor js =(JavascriptExecutor)driver;
	    js.executeScript("done();");
 
	    test.log(Status.PASS,"Here we have tested the condition and result is displayed ");
		//driver.close();
		//driver.quit();
		test.log(Status.INFO,"Driver closed");
		
		extent.flush();
		try {
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);



		
		 // now copy the  screenshot to desired location using copyFile //method
		FileUtils.copyFile(src, new File("D:/javascriptTest.png"));//path of image
		
		
		
		
		
		
		}

		catch (IOException e)
		 {
		  System.out.println(e.getMessage());

		 }
		
		
		
	    
		}

	/*@Test
	public void testNameAndPassword2(){
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\User\\Desktop\\Mariyam\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
	
		
		
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://localhost:8080/automationTest/";	
		driver.get(baseUrl);
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
*/
}
