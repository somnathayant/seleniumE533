package com.ayantsoft.cucumberDemo.test;

import org.testng.annotations.Test;

public class TestDemo {
		
	@Test
	public static void testCase1() {
		System.out.println("This is a Test Case 1");
	}
	
	@Test
	public static void testCase2() {
		System.out.println("This is Test Case 2");
	}
	
	@Test
	public static void testCase3(){
		System.out.println("This is Test Case 3");
	}
}
