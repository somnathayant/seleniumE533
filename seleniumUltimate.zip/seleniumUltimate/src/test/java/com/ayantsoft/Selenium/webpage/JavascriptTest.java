package com.ayantsoft.Selenium.webpage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class JavascriptTest {

	@Test
	public void fun(){
		WebDriver driver = new FirefoxDriver();
		
		String baseUrl = "http://localhost:8082/seleniumUltimate/";	
	    driver.get(baseUrl);
	    
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
	    WebElement userId = driver.findElement(By.id("userid"));					 
	    WebElement userPass = driver.findElement(By.id("password"));					 
	     
	     
	    userId.sendKeys();//no words so validation works
	    userPass.sendKeys("selenium@123");//password less or greater then 5 words so validation works
	    
	    JavascriptExecutor js =(JavascriptExecutor)driver;
        js.executeScript("done();");
 
        
	}



}
