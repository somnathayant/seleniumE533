package com.ayantsoft.controller;



public class Employee {
		
		private String name;
		
		//getter and setter
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
		
}
