package com.ayantsoft.Selenium.webpage;

import org.testng.annotations.Test;

public class Example {

	@Test
	public void testSelenium()
	{
		
		
		
		
		
		
		
	}	
	
}
