package com.ayantsoft.Selenium.webpage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class DatabaseTest {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","mysql");
		
		
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	
	
	public static int checkSaveData(){//getting the data from user screen wrrapedup in class object
		int status=0;
		try{
			Connection con=DatabaseTest.getConnection();
			
			
			PreparedStatement ps1=con.prepareStatement("insert into Address(pin,state,city) values (?,?,?)",Statement.RETURN_GENERATED_KEYS);
			
			ps1.setInt(1,223322);
			
			ps1.setString(2,"Alabama");
			
			ps1.setString(3,"Alabama");
			
			status=ps1.executeUpdate();
			
			int generatedKey = 0;
			ResultSet rs = ps1.getGeneratedKeys();//single column
			if (rs.next()) {
			    generatedKey = rs.getInt(1);
			}
			PreparedStatement ps=con.prepareStatement("insert into emp(name,password,email,addressId) values (?,?,?,?)");
			ps.setString(1,"somnath");
			ps.setString(2,"som");
			ps.setString(3,"som@gmail.com");
			ps.setInt(4,generatedKey);
			
			status=ps.executeUpdate();
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	
	
	public static void getAllEmployees(){
		
		try{
			Connection con=DatabaseTest.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from emp INNER JOIN Address ON emp.addressId=Address.id");

			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
					
				System.out.println(rs.getInt(1));
				
				
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		
	}

		
}
